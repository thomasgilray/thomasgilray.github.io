
var doma = DOMAssistant;
var graph = undefined;

doma.DOMReady(
  function() {
      setupCodeView();
  });


function setupCodeView()
{
    $('body').addContent('<div id="codeview"></div>');
    $('#codeview').addContent(prettyprint(target, 0));
    $('body').addContent('<div id="graph"></div>');

    // Generate a graph from reachable
    var nodes = reachable.keys;
    var gnodes = [];
    var gedges = [];
    for (var i = 0; i < nodes.length; ++i)
    {
        var node = { data: { id: nodes[i] } };
	gnodes.push(node);
	var succs = reachable[nodes[i]];
	if (succs)
	    for (var j = 0; j < succs.length; ++j)
	    {
	        var edge = { data: { id: nodes[i]+'-'+succs[j], source: nodes[i], target: succs[j] } };
	        gedges.push(edge);
    	    }    
    }

    graph = cytoscape({
	container: document.getElementById('graph'),
	elements: gnodes.concat(gedges), //{ nodes: gnodes, edges: gedges}, 
	style: [ // the stylesheet for the graph
	    {
		selector: 'node',
		css: {
		    'background-color': '#333',
		    'label': 'data(id)'
		}
	    },
	    {
		selector: 'edge',
		css: {
		    'target-arrow-shape': 'triangle',
		    'target-arrow-color': '#333',
		    'arrow-width': 8,
		    'width': 3
		}
	    }
	],
	layout:
	{
	    name: 'cose',
	    rows: 1
	}
    });
}


function prettyprint(e, ind)
{
    function nbsp(ind) {
	if (ind <= 0)
	    return "";
	else
	    return "&nbsp;&nbsp;" + nbsp(ind-1);
    }
    
    if (e.form == 'let')
    {
	return "<sub>" + e.id + "</sub>(let ([" + e.x + " " + prettyprint(e.e0,ind) + "])"
	    + "<br />" + nbsp(ind+1) + prettyprint(e.e1,ind+1) + ")";
    }
    else if (e.form == 'lambda')
    {
	return "<sub>" + e.id + "</sub>(lambda (" + e.x + ")"
	    + "<br />" + nbsp(ind+1) + prettyprint(e.e0,ind+1) + ")";	
    }
    else if (e.form == 'call')
    {
	return "<sub>" + e.id + "</sub>(" + e.f + " " + e.a  + ")";
    }
    else if (e.form == 'var')
    {
	return "<sub>" + e.id + "</sub>" + e.x;
    }
    else if (e.form == 'true')
    {
	return "<sub>" + e.id + "</sub>#t";
    }
    else if (e.form == 'false')
    {
	return "<sub>" + e.id + "</sub>#f";
    }
    else
	alert('Unrecognized language form.');
}
